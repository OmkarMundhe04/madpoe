package com.omkar.ratingbar;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    RatingBar ratingBar;
    TextView textView1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ratingBar = findViewById(R.id.ratingBar);
        textView1 = findViewById(R.id.textView1);

        ratingBar.setOnRatingBarChangeListener(
                (ratingBar, rating, fromUser) -> {

                    textView1.setText(
                            "Selected Rating : " + rating);

                });
    }
}