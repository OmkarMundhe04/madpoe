package com.omkar.storedataintofile;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {

    EditText editText1;
    Button button1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.editText1);
        button1 = findViewById(R.id.button1);

        button1.setOnClickListener(v -> {

            try {

                String data =
                        editText1.getText().toString();

                FileOutputStream fos =
                        openFileOutput(
                                "myfile.txt",
                                MODE_PRIVATE);

                fos.write(data.getBytes());

                fos.close();

                Toast.makeText(
                        MainActivity.this,
                        "Data Stored Successfully",
                        Toast.LENGTH_SHORT).show();

            } catch(Exception e) {

                e.printStackTrace();
            }

        });
    }
}