package com.omkar.progressbar;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ProgressBar progressBar;
    TextView textView1;
    Button button1;

    int progress = 0;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        textView1 = findViewById(R.id.textView1);
        button1 = findViewById(R.id.button1);

        button1.setOnClickListener(v -> {

            progress = 0;

            Handler handler = new Handler();

            new Thread(() -> {

                while(progress <= 100)
                {
                    int value = progress;

                    handler.post(() -> {

                        progressBar.setProgress(value);

                        textView1.setText(
                                value + "%");
                    });

                    progress++;

                    try {
                        Thread.sleep(100);
                    }
                    catch(Exception e) {
                        e.printStackTrace();
                    }
                }

            }).start();

        });
    }
}