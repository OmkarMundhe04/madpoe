package com.omkar.displaydatasql;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button button1;
    TextView textView1;
    SQLiteDatabase db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = findViewById(R.id.button1);
        textView1 = findViewById(R.id.textView1);

        db = openOrCreateDatabase(
                "StudentDB",
                MODE_PRIVATE,
                null);

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS student(" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "name TEXT," +
                        "course TEXT)");

        db.execSQL(
                "INSERT INTO student(name,course) " +
                        "VALUES('Omkar','CSE')");

        button1.setOnClickListener(v -> {

            Cursor cursor =
                    db.rawQuery(
                            "SELECT * FROM student",
                            null);

            String data = "";

            while(cursor.moveToNext())
            {
                data += "ID : "
                        + cursor.getInt(0)
                        + "\nName : "
                        + cursor.getString(1)
                        + "\nCourse : "
                        + cursor.getString(2)
                        + "\n\n";
            }

            textView1.setText(data);

        });
    }
}