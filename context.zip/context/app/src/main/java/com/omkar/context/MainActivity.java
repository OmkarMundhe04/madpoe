package com.omkar.context;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = findViewById(R.id.button1);

        registerForContextMenu(button1);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        menu.setHeaderTitle("Select Option");

        menu.add(0,1,0,"Edit");
        menu.add(0,2,0,"Delete");
        menu.add(0,3,0,"Share");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {

        if(item.getItemId()==1)
        {
            Toast.makeText(this,"Edit Selected",
                    Toast.LENGTH_SHORT).show();
        }

        else if(item.getItemId()==2)
        {
            Toast.makeText(this,"Delete Selected",
                    Toast.LENGTH_SHORT).show();
        }

        else if(item.getItemId()==3)
        {
            Toast.makeText(this,"Share Selected",
                    Toast.LENGTH_SHORT).show();
        }

        return true;
    }
}