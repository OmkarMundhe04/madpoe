package com.omkar.alert;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;

import android.os.Bundle;
import android.content.DialogInterface;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.button1);

        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder =
                        new AlertDialog.Builder(MainActivity.this);

                builder.setTitle("Alert Dialog");
                builder.setMessage("Do you want to exit?");

                builder.setPositiveButton("YES",
                        new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(
                                    DialogInterface dialog,
                                    int which) {

                                Toast.makeText(
                                        getApplicationContext(),
                                        "YES Clicked",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });

                builder.setNegativeButton("NO",
                        new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(
                                    DialogInterface dialog,
                                    int which) {

                                Toast.makeText(
                                        getApplicationContext(),
                                        "NO Clicked",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });

                builder.show();
            }
        });
    }
}