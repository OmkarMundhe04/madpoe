package com.omkar.togglebutton;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ToggleButton toggleButton;
    TextView textView1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggleButton = findViewById(R.id.toggleButton);
        textView1 = findViewById(R.id.textView1);

        toggleButton.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {

                    if(isChecked)
                    {
                        textView1.setText(
                                "Toggle Button ON");
                    }
                    else
                    {
                        textView1.setText(
                                "Toggle Button OFF");
                    }
                });
    }
}