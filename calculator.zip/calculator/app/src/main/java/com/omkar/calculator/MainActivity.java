package com.omkar.calculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editText1, editText2;
    Button add, sub, mul, div;
    TextView textView1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);

        add = findViewById(R.id.button1);
        sub = findViewById(R.id.button2);
        mul = findViewById(R.id.button3);
        div = findViewById(R.id.button4);

        textView1 = findViewById(R.id.textView1);

        add.setOnClickListener(v -> {

            double a =
                    Double.parseDouble(
                            editText1.getText().toString());

            double b =
                    Double.parseDouble(
                            editText2.getText().toString());

            textView1.setText(
                    "Result = " + (a+b));
        });

        sub.setOnClickListener(v -> {

            double a =
                    Double.parseDouble(
                            editText1.getText().toString());

            double b =
                    Double.parseDouble(
                            editText2.getText().toString());

            textView1.setText(
                    "Result = " + (a-b));
        });

        mul.setOnClickListener(v -> {

            double a =
                    Double.parseDouble(
                            editText1.getText().toString());

            double b =
                    Double.parseDouble(
                            editText2.getText().toString());

            textView1.setText(
                    "Result = " + (a*b));
        });

        div.setOnClickListener(v -> {

            double a =
                    Double.parseDouble(
                            editText1.getText().toString());

            double b =
                    Double.parseDouble(
                            editText2.getText().toString());

            textView1.setText(
                    "Result = " + (a/b));
        });
    }
}