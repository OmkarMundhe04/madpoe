package com.omkar.insertdatasql;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editText1, editText2;
    Button button1;
    SQLiteDatabase db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);
        button1 = findViewById(R.id.button1);

        db = openOrCreateDatabase(
                "StudentDB",
                MODE_PRIVATE,
                null);

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS student(" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "name TEXT," +
                        "course TEXT)");

        button1.setOnClickListener(v -> {

            String name =
                    editText1.getText().toString();

            String course =
                    editText2.getText().toString();

            ContentValues values =
                    new ContentValues();

            values.put("name", name);
            values.put("course", course);

            db.insert(
                    "student",
                    null,
                    values);

            Toast.makeText(
                    MainActivity.this,
                    "Data Inserted Successfully",
                    Toast.LENGTH_SHORT).show();
        });
    }
}