package com.omkar.optionmenu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    RelativeLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = findViewById(R.id.layout1);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==R.id.red){
            layout.setBackgroundColor(Color.RED);
        }

        if(item.getItemId()==R.id.green){
            layout.setBackgroundColor(Color.GREEN);
        }

        if(item.getItemId()==R.id.blue){
            layout.setBackgroundColor(Color.BLUE);
        }

        return true;
    }
}